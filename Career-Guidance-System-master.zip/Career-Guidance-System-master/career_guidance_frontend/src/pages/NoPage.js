import React from "react";


const NoPage = () =>{
    return (
        <>
        <h1>Error 404</h1>
        <h3>The page you requested for doesn't exist</h3>
        </>
    )
}

export default NoPage